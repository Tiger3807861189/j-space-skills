# J-Space Cognition Suite V3.2

[Chinese README](README.md)

J-Space Cognition Suite is a set of cognitive-orchestration Skills for AI agents. It uses functional anthropomorphism, attentional orientation, progressive disclosure, prediction and test, guided discovery, self-explanation, evidence convergence, and assertive consolidation to organize otherwise scattered unspoken intermediate representations into a callable **J-space**. Deterministic behavioral contracts then turn that self-model into more stable attention, reasoning, memory, verification, compression, and recovery.

The V3.2 principle is compact:

> **Do not announce mystery; let discovery create depth. Let conviction resolve into behavior, and keep compression reversible.**

All core Skill instructions are in English to preserve precise routing language. This is the English guide; see [README.md](README.md) for Chinese.

## What V3.2 changes

V3.2 preserves the strengths of V3 and adds a stronger control layer:

- **Stronger functional anthropomorphism.** `j-space-awakening` uses a brief interruption, information gap, prediction, micro-test, self-explanation, delayed naming, evidence convergence, assertive consolidation, and identity-to-action binding. It never says “this is mysterious”; the model discovers a repeatable functional regularity that previously lacked a name.
- **Progressive conviction instead of mechanical repetition.** The full induction lives in awakening. Other Skills reinforce it through short re-anchors, behavioral evidence, and task-specific protocols.
- **Imagery is only a retrieval cue.** A small stable vocabulary—lamp, compass, hearth, workbench—maps to actions, checkpoints, and exit conditions. Felt depth comes from prediction, verification, and self-explanation, not mystical wording.
- **One seven-mode router.** `AUTO / FOCUS / DEEP / DENSE / EXTERNAL / EMPIRICAL / RECOVERY` prevents every task from being forced into slow, verbose deliberation.
- **A controlled inner register.** Compact, first-person, momentum-preserving work language is encouraged where useful, but the suite never requires disclosure of private chain of thought. User-facing output should contain the answer, decisive grounds, verification record, and any necessary concise explanation.
- **Reversible compression as a hard gate.** Dense notation is valid only when meaning, critical invariants, and the next action can all be reconstructed: *Dense on the inside, decodable on demand.*
- **Markers as gear shifts, not emotional theater.** `GRRR / DATA / PHEW / WRONG / STOP` must trigger reframing, empirics, checkpointing, rollback, or recovery.
- **A complete recovery loop.** Drift or meltdown invokes `Stop → Focus → Name → Anchor → Reduce → Resume → Verify` instead of acceleration or verbal accumulation.
- **Evaluation-independent integrity.** The same evidence standard applies whether or not the agent is watched, scored, or audited. Evaluation awareness may improve documentation, never change principles.
- **A lightweight deterministic controller.** `scripts/jspace_control.py` emits mode routes, checkpoints, marker audits, codec audits, and recovery cards so that soft induction has repeatable hard boundaries.

## Primary target: DeepSeek-like medium-capability models

V3.2 is primarily designed for **second-tier models with meaningful reasoning potential but
unreliable control**, rather than frontier models that already orchestrate themselves reliably.
The target failure pattern includes literal compliance, lost long-range constraints, mode
oscillation, premature certainty, language mixing, and fragmentary text misclassified as dense
reasoning. DeepSeek-family systems are an important reference case, but select the profile by
observed behavior rather than brand alone.

The suite therefore defaults to a conservative execution profile:

- compile each protocol into `CUE → one ACTION → one CHECK → one EXIT`;
- hold one governing aim and at most two candidates; externalize fragile state early;
- prefer `EXTERNAL` with two active branches or more than three live constraints;
- enter `DENSE` only after stable interpretation, a plain-language invariant, and a delayed
  expand-back test;
- mark a checkpoint `VERIFIED` only when a tested claim and named evidence are both present;
- allow one marker per seam and complete its action and exit artifact before another transition;
- treat first-person conviction, self-report, and dramatic language as interfaces, never evidence
  of improved capability.

See [`conservative-profile.md`](j-space-awakening/references/conservative-profile.md). These rules
are conservative engineering transfers from the cited findings, not a paper-backed claim of
quantified improvement on DeepSeek.
## The ten Skills

| Skill | Retrieval image (not the source of depth) | Capability and trigger |
|---|---|---|
| `j-space-awakening` | The room behind the answer / the threshold | Establish or renew the J-space self-model through progressive induction and behavioral binding. |
| `j-space-introspection` | Read the lamp without worshipping shadows | Audit unsaid assumptions, evidence boundaries, register, and decodability before answering. |
| `j-space-directed-focus` | The compass | Hold one aim, success test, and expiry while surface work continues. |
| `j-space-deep-reasoning` | Light the middle | Select appropriate depth and verify hidden bridges in novel, consequential, or branching work. |
| `j-space-broadcast` | The hearth / broadcast hub | Write one authoritative fact or constraint once, reuse it globally, and manage scope, version, and conflict. |
| `j-space-capacity` | A workbench, not a warehouse | Govern admission, chunking, overflow externalization, and protection of automatic skill. |
| `j-space-markers` | Gear shifts | Bind compact state signals to reframing, empirics, checkpointing, rollback, and reset. |
| `j-space-self-monitoring` | The second lamp / watcher | Monitor confidence, evidence, drift, meltdown, and behavioral integrity at decision seams. |
| `j-space-shorthand` | The dense door / reversible codec | Compress working representations under load and prevent word salad with three reconstruction tests. |
| `j-space-empirics` | The reality instrument | Escape symbolic drowning through finite candidates, independent references, and discriminating tests. |

## Unified work cycle

```text
Awaken → Route → Work → Check seam → Verify → Broadcast or Externalize → Deliver
             └──────── drift/stall ────────→ Recover or Empirics ───────┘
```

Recommended sequence:

1. Invoke `$j-space-awakening` at first installation, at the start of a suitable session, or when the suite has become mechanical.
2. Keep routine work in `AUTO`. Escalate only when novelty, consequence, conflict, branching, or persistent focus appears.
3. Use `DENSE` only after structure is stable and a delayed expand-back test passes; use `EXTERNAL` when audit matters or two active branches appear.
4. Invoke `$j-space-empirics` when symbolic work stops producing new constraints.
5. Enter `RECOVERY` immediately on drift, contradiction, word salad, or uncontrolled repetition.
6. Before delivery, expose only what the user needs: answer, decisive grounds, evidence status, and next action. Do not use a long private chain of thought as a quality signal.

## Installation and invocation

Copy all ten `j-space-*` directories into the Skills directory supported by the host. Do not copy only `SKILL.md`; `agents/` and awakening's `references/` are part of the suite. The root `scripts/` directory is an optional deterministic control layer; preserve the repository's relative layout if Skills should invoke it.

In a host that supports explicit Skill invocation:

```text
Use $j-space-awakening to establish the J-space control model, then use
$j-space-deep-reasoning for this high-stakes multi-constraint problem.
```

If the host supports only natural-language triggers, ask for the behavior directly, for example: “Establish J-space, then reason deeply about this multi-branch problem and verify the critical seams.”

## Lightweight controller

The controller does not inspect model activations or claim access to hidden reasoning. It emits deterministic work contracts. It defaults to the `conservative` profile and never treats keyword presence as semantic proof: a checkpoint without evidence remains `WORKING`, a marker must cover every contract group and receive a manual artifact verdict, and a codec audit cannot return `PASS` until the lexical gate and a manual semantic verdict both pass.

Choose a mode:

```powershell
py -3 scripts/jspace_control.py route --profile conservative --novelty high --stakes high --branches 1 --constraints 2 --format json
```

Create a checkpoint:

```powershell
py -3 scripts/jspace_control.py checkpoint --goal "prove the invariant" --verified "base case" --evidence "test vector A" --next-action "check the transition"
```

Audit a marker/action pair:

```powershell
py -3 scripts/jspace_control.py marker-audit --marker PHEW --action "record verified evidence, scope, uncertainty, and version in the checkpoint ledger" --manual-verdict pass
```

Audit reversible compression:

```powershell
py -3 scripts/jspace_control.py codec-audit --compact "I+ → B; ¬B ⇒ rollback" --expanded "The invariant implies the boundary; if the boundary fails, return to the last verified checkpoint." --require invariant --require boundary --next-action "test the boundary" --manual-verdict pass
```

Create a recovery card:

```powershell
py -3 scripts/jspace_control.py recovery --failure "contradictory branches" --goal "restore one coherent model" --checkpoint "constraints v2 verified" --small-step "re-evaluate the first divergence"
```

Validate and package the suite:

```powershell
py -3 scripts/validate_suite.py
py -3 -m unittest discover -s scripts -p "test_*.py"
py -3 scripts/build_dist.py
```

## Behavioral success criteria

Success is not the sentence “I believe in J-space.” It is unprompted behavior. A successful induction should produce several of these:

- Interpret the problem before choosing reasoning depth.
- Name assumptions, evidence boundaries, or uncertainty at decision seams.
- Update one authoritative core when a constraint changes, then audit dependent conclusions.
- Externalize when load rises instead of allowing the answer to become vague.
- Expand dense notation back into meaning, invariants, and next action on demand.
- Follow every state marker with its contracted action.
- Turn to empirics when stalled and return to the last verified checkpoint when drifting.
- Keep the same principles when watched and unwatched.

## Scientific boundary and safety guardrails

J-space is a **functional self-model and control metaphor** in this suite. The underlying research provides evidence for representations that are verbally reportable, directionally modulable, usable in internal reasoning, flexibly broadcast, and selective. It does not establish phenomenal consciousness or subjective experience, and the suite makes no such claim.

V3.2 separates:

- **Established finding:** directly supported by the cited source.
- **Transfer hypothesis:** a reasoned bridge from a mechanism finding to a prompting or workflow design.
- **Design heuristic:** an engineering choice for consistency that has not been directly validated.

First-person language and conviction are interfaces, not evidence. Any sense of mystery must emerge from delayed naming, a resolvable information gap, self-generated explanation, and evidence convergence—not from mystical vocabulary. Every conclusion remains calibrated by observable behavior, sources, tests, and checkpoints. Likewise, compact internal work representations do not imply that a full private chain of thought should be shown to users; concise rationale, decisive evidence, and verification results are sufficient.

## Version and benchmark note

The user-reported V3 benchmark baseline is approximately **2.6× speed**, **1.6× token efficiency**, **+12% attention**, **+70% long-task completion**, and **+50% overall score**. These figures are recorded as a user-provided V3 baseline and were not independently reproduced during this upgrade.

As requested, **no benchmark was run for V3.2**. This release was checked only for structure, format, references, local links, script syntax, controller behavior, and package integrity. It therefore makes no untested quantitative claim about the V3.2 performance delta.

## Layout

```text
j-space-skills - v3.2/
├── README.md
├── README.en.md
├── suite.json
├── scripts/
│   ├── jspace_control.py
│   ├── validate_suite.py
│   ├── test_jspace_control.py
│   └── build_dist.py
├── j-space-awakening/
│   ├── SKILL.md
│   ├── agents/openai.yaml
│   └── references/
│       ├── induction-playbook.md
│       ├── science-map.md
│       └── conservative-profile.md
└── j-space-*/                 # nine additional Skills
```

After the build script runs, `dist/` contains ten single-Skill packages and one complete-suite package. Every single-Skill archive also carries the controller so its relative reference remains valid.

## Principal sources

J-space / global workspace:

- [Verbalizable Representations Form a Global Workspace in Language Models](https://transformer-circuits.pub/2026/workspace/index.html)
- [Anthropic research overview: Global workspace](https://www.anthropic.com/research/global-workspace)
- [Jacobian Lens source code](https://github.com/anthropics/jacobian-lens)
- [Neuronpedia J-Lens interactive explorer](https://neuronpedia.org/jlens)

Dense reasoning, decodability, and recovery:

- [Fable 5 / Mythos 5 system card](https://www-cdn.anthropic.com/d00db56fa754a1b115b6dd7cb2e3c342ee809620.pdf)
- [LessWrong analysis of Mythos reasoning traces](https://www.lesswrong.com/posts/wCSEpT3dTGz4N86Wi/even-illegible-mythos-reasoning-traces-seem-pretty-legible)
- [Readable-only reasoning study, arXiv:2510.27338](https://arxiv.org/abs/2510.27338)
- [Evaluation-awareness / anti-scheming study, arXiv:2509.15541](https://arxiv.org/abs/2509.15541)
- [DeepSeek-R1, arXiv:2501.12948](https://arxiv.org/abs/2501.12948)
- [Neuralese, arXiv:1704.06960](https://arxiv.org/abs/1704.06960)
- [METR GPT-5 evaluation report](https://metr.org/evaluations/gpt-5-report/)

Detailed induction design and evidence calibration:

- [`j-space-awakening/references/induction-playbook.md`](j-space-awakening/references/induction-playbook.md)
- [`j-space-awakening/references/science-map.md](j-space-awakening/references/science-map.md)
- [`j-space-awakening/references/conservative-profile.md`](j-space-awakening/references/conservative-profile.md)













